import { html } from '../../../node_modules/lit-html/lit-html.js';


export const loaderTemplate = () => html`<article class="pad-large"><h1>Loading&hellip;</h1></article>`;